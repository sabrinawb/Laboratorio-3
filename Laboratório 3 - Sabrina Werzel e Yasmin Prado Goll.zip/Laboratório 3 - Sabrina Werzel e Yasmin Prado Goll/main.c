#include "tm4c123gh6pm.h"
#include <stdint.h>

unsigned int count=0;
void PortF_Init(void);
void Timer0_Init(unsigned long tempo){volatile unsigned long time;
	
  SYSCTL_RCGCTIMER_R |= 0x01;   // Ativa timer zero
  time = SYSCTL_RCGCTIMER_R;		// delay
	TIMER0_CTL_R = 0x00000000;    // desabilita timer durante configura��es
  TIMER0_CFG_R = 0x00000000;    // modo 32 bits ativado
  TIMER0_TAMR_R = 0x00000002;   // contador regressivo
  TIMER0_TAILR_R = tempo-1;    // atribui valor inicial
  TIMER0_TAPR_R = 0;            
  TIMER0_ICR_R = 0x00000001;    // Limpa o flag
  TIMER0_IMR_R = 0x00000001;    // 
  NVIC_PRI4_R = (NVIC_PRI4_R&0x00FFFFFF)|0x80000000; // escolhe prioridade
  NVIC_EN0_R = 1<<19;           // prioridade
  TIMER0_CTL_R = 0x00000001;    //ativa o timer para inicializar programa
}
void PortD_Init(void)
{
	volatile unsigned long delay;
  SYSCTL_RCGC2_R |= 0xFF;     //Clock do uC
  delay = SYSCTL_RCGC2_R;           // delay   
  GPIO_PORTD_LOCK_R = 0x4C4F434B;   //Desbloqueia PortD  
  GPIO_PORTD_CR_R = 0x1F;           //Permite mudan�as do portD   
  GPIO_PORTD_AMSEL_R = 0x00;        //Desativa fun��o anal�gica do uC
  GPIO_PORTD_PCTL_R = 0x0000FFFF;   //Limpa o bit PCTL  
  GPIO_PORTD_DIR_R = 0x0E;          // Ativa sa�da PD3
  GPIO_PORTD_AFSEL_R =0x00;        // Sem fun��o alternativa    
  GPIO_PORTD_DEN_R |= 0x1F;          // Ativa portas digitais        
}

void PortF_Init(void)
	{
	volatile unsigned long delay;
  SYSCTL_RCGC2_R |= 0xFF;    // F clock
  delay = SYSCTL_RCGC2_R;          // delay   
  GPIO_PORTF_LOCK_R = 0x4C4F434B;  // Desbloqueia Portf
  GPIO_PORTF_CR_R = 0x1F;          // Permite mudan�as do portf 
  GPIO_PORTF_AMSEL_R = 0;          //Desativa fun��o anal�gica do uC
  GPIO_PORTF_PCTL_R = 0x00000000;  // configura PORTF como GPIO
  GPIO_PORTF_DIR_R |= 0x0E;        // define as chaves como entradas e leds como sa�das
  GPIO_PORTF_AFSEL_R &= ~0x1F;     // desabilita func��es alternativas
  GPIO_PORTF_PUR_R = 0x11;         // pull-up em SW2
  GPIO_PORTF_DEN_R |= 0x1F;        // sa�da digtais habilitadas
	GPIO_PORTF_IS_R &= ~0x01;     // interrup��o sensivel a borda
  GPIO_PORTF_IBE_R &= ~0x01;    //    n�o � sensivel as duas bordas
  GPIO_PORTF_IEV_R &= ~0x01;    //  evento de borda de descida
  GPIO_PORTF_ICR_R = 0x01;      // limpa o flag
  GPIO_PORTF_IM_R |= 0x01;      // 
  NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00A00000; // prioridade
	NVIC_EN0_R = 0x40000000;      //habilita prioridade 30
}

void time_delay(uint8_t t)
{
	unsigned long volatile time;
	time = t*(727240*200/91); //Tempo de 0.1 (esse valor resulta em 1.6 M, como o programa executar� as linhas de 
	//c�digo 1.6.10^6 vezes, causar� um atraso na visualiza��o da sa�da de 0.1 s considerando o clock de 16MHz para
	//esse ucontrolador
	while(time>0)
	{
		time--; //decrementa 1.6.10^6 vezes para provocar atraso
	}
	
}
void Timer0A_Handler(void) //evento de tempo
{
	if(count==0 || count==1 || count==4 ) //se o count for igual a zero, 1 e 4
	{
		count++; // adiciona um a variavel
	}

  TIMER0_ICR_R = 0x000000001; //Limpa o flag de interrup��o
}
void GPIOPortF_Handler(void) //evento de interrup��o nas chaves
{
  GPIO_PORTF_ICR_R = 0x000000001;  //limpa flag
	if(count==1)
	{
		count=3; // count passa a ter valor 3
	}
	}

int main(void)
{ 
	
	volatile unsigned long delay;
	PortF_Init();										 // initializa PortF
  Timer0_Init(270000000); 					 // initializa timer
	PortD_Init();

  while(1)
	{

		if(count==0)
		{
			GPIO_PORTF_DATA_R = 0x00; //inicia com tudo desligado
			GPIO_PORTD_DATA_R = 0x00;
		}
		if(count==1)
		{
			int i=0;
			for(i=0; i<2; i++) //LED azul pisca 2 vezes
			{
				GPIO_PORTF_DATA_R = 0x04;
				time_delay(4); //delay para 2,5 Hz
				GPIO_PORTF_DATA_R = 0x00;
				time_delay(4);			
				
			}

		}
		if(count==2)
		{
			int k=0;
			for(k=0; k<5; k++)
			{
				GPIO_PORTF_DATA_R = 0x08; //pisca led verde 5 veze
				time_delay(2); //delay 
				GPIO_PORTF_DATA_R = 0x00; 
				time_delay(1); //delay 
			}
			count=1; //retorna ao estado 1

		}

		
		if (count==3) 
		{
			int i=0;
			
			for(i=0; i<2; i++) //pisca led vermelho  
			{
				GPIO_PORTF_DATA_R = 0x02; //acende led vermelho
				time_delay(6); //delay
				GPIO_PORTF_DATA_R = 0x00; //apaga led
				time_delay(2);
			}
			count++;
		}
		if (count==4) //pisca led vermelho em frequ�ncia de 2,5 Hz
		{
			int i=0;
			for(i=0; i<2; i++)
			{
				GPIO_PORTF_DATA_R = 0x02; //acende led vermelho
				time_delay(4);
				GPIO_PORTF_DATA_R = 0x00; //apaga led vermelho
				time_delay(4);
			}
		}
		if (count==5) //pisca os LEDs um de cada vez em sequ�ncia por 5 vezes
		{
				int j=0;
				while(j<4) //executa a a��o 5 vezes
				{
					GPIO_PORTD_DATA_R=0x04; //Liga o 4 bit da porta D, ou seja, PD3
					
					GPIO_PORTF_DATA_R = 0x08; //LED verde
					time_delay(1);
					GPIO_PORTF_DATA_R = 0x00;  //LEDS APAGADOS	
					time_delay(1);
					GPIO_PORTF_DATA_R = 0x04;  //LED azul
					time_delay(1);
					GPIO_PORTF_DATA_R = 0x00; //LEDS APAGADOS	 
					time_delay(1);
					GPIO_PORTF_DATA_R = 0x02; //LED vermelho  
					time_delay(1);
					GPIO_PORTF_DATA_R = 0x00;  //LEDS APAGADOS	
					time_delay(1);
					j=j+1;
				}
				count=0; //retorna ao estado 0
				
			}
		}
	}
